package com.wnsen.fallback;

import com.wnsen.feigin.ProductFeigin;
import org.springframework.stereotype.Component;

@Component
public class ProductFeignFallBack implements ProductFeigin {
    @Override
    public String getProductInfo() {
        return "超时啦，哈哈哈";
    }
}
