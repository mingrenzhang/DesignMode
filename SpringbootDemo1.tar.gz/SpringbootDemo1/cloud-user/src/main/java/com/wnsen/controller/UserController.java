package com.wnsen.controller;

import com.wnsen.feigin.ProductFeigin;
import com.wnsen.rabbitmq.MqSender;
import entity.EmailInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RefreshScope
@RequestMapping("/user")
public class UserController {
    @Autowired
    ProductFeigin productFeigin;
    @Autowired
    MqSender mqSender;

    @Value("${info}")
    private String userInfo;

    @RequestMapping("/getUserInfo")
    @ResponseBody
    public String getUserName(){
        EmailInfo info = new EmailInfo();
        info.setId(1L);
        info.setMessage("message");
        mqSender.send(info);
        return this.userInfo;
    }

    @RequestMapping("/getProductInfo")
    @ResponseBody
    public String getProductInfo(){
        return productFeigin.getProductInfo();
    }

}
