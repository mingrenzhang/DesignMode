package com.wnsen.util;

import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;

import java.util.concurrent.TimeUnit;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2023/2/2 上午10:34
 */
public class RedisUtils {

    @Autowired
    RedisTemplate redisTemplate;

    /**
     * 指定缓存失效时间
     * @param key
     * @param time
     * @return
     */
    public boolean expire(String key,long time){
        boolean isSetSuccess = false;
        if (time > 0){
            isSetSuccess = redisTemplate.expire(key,time, TimeUnit.SECONDS);
        }
        return isSetSuccess;
    }

    public long getExpire(String key){
        return Strings.isBlank(key)? 0 : redisTemplate.getExpire(key);
    }

}
