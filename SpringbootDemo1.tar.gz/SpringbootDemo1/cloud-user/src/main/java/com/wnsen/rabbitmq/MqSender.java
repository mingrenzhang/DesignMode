package com.wnsen.rabbitmq;

import entity.EmailInfo;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class MqSender {

    @Autowired
    private AmqpTemplate amqpTemplate;

    public void send(EmailInfo emailInfo){
        this.amqpTemplate.convertAndSend("direct","downOrder",emailInfo);
    }
}
