package com.wnsen.feigin;

import com.wnsen.fallback.ProductFeignFallBack;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;

@FeignClient(value = "product",path = "/product",fallback = ProductFeignFallBack.class)
public interface ProductFeigin {
    @RequestMapping(value = "/getInfo")
    public String getProductInfo();
}
