package com.wensen.rabbitmq;

import entity.EmailInfo;
import org.springframework.amqp.core.ExchangeTypes;
import org.springframework.amqp.rabbit.annotation.*;
import org.springframework.stereotype.Component;

@Component
@RabbitListener(bindings = @QueueBinding(
        value = @Queue(value = "down",autoDelete = "true"),
        exchange = @Exchange(value = "direct",type = ExchangeTypes.DIRECT),
        key = "downOrder")
)
public class EmailReceiver {
    @RabbitHandler
    public void process(EmailInfo info){
        System.out.println("====================receive :"+info.getMessage());
    }
}
