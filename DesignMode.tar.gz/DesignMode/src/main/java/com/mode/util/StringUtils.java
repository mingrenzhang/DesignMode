package com.mode.util;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/10/11 上午9:39
 */
public class StringUtils {

    public static boolean isEmpty(String str){
        if (str == null || str == ""){
            return true;
        }
        return false;
    }
}
