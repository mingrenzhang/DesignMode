package com.mode;


import com.mode.action.iterator.Student;

import java.util.ArrayList;
import java.util.List;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/10/21 上午10:47
 */
public class Test extends Student{


    private static int DEFAULT_INT = 3;

    public Test(String name, String number) {
        super(name, number);
    }

    public static void main(String[] args) {
        int[] a = {1,2,3};
        toArray1(a);
        List list = new ArrayList<>();
        list.add(1);
        list.add(2);
        list.add(3);
        //System.out.println(list.toString());

    }

    private static void toArray1(int[] array){
        System.out.println(array.toString());
        for (int i=0;i<DEFAULT_INT;i++){
            System.out.println(i+":"+array[i]);
        }
    }
}
