package com.mode.action.strategy;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/9/29 下午5:18
 */

/**
 * 行为模式-策略模式
 * @author zhangmr
 */
public class StrategyMain {

    public static void main(String[] args) {
        CashContext cashContext = new CashContext(new CashNormal());
        System.out.println("原价："+cashContext.getResult(20));

        CashContext cashContext1 = new CashContext(new CashRebate(0.7));
        System.out.println("打折："+cashContext1.getResult(20));
    }
}
