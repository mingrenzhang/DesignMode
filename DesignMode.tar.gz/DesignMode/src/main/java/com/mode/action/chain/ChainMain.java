package com.mode.action.chain;

import com.mode.action.iterator.Student;

import java.util.ArrayList;
import java.util.List;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/10/11 上午9:57
 * 行为模式-责任链模式
 */

public class ChainMain {

    private static List<Student> studentList = new ArrayList<>();

    public static void main(String[] args) {
        initStudent();
        AbstractCheckStudent studentCheck = getStudentCheck();
        studentCheck.handleCheck(studentList);
        System.out.println("符合条件的学生："+studentList);

    }

    /**
     * 设置责任链顺序
     * @return 包含责任链的对象
     */
    private static AbstractCheckStudent getStudentCheck(){
        AbstractCheckStudent stNameCheck = new StNameCheck();
        AbstractCheckStudent stAgeCheck = new StAgeCheck();
        //把年龄校验设置为名字校验的下一个处理者
        stNameCheck.setAbsCheckStudent(stAgeCheck);
        return stNameCheck;
    }

    private static void initStudent(){

        Student student1 = new Student("张三","1");
        student1.setAge("18");
        Student student2 = new Student("李四","2");
        student2.setAge("18");
        Student student3 = new Student("王五","3");
        student3.setAge("18");
        Student student4 = new Student("小明","4");
        student4.setAge("18");
        Student student5 = new Student("小李","5");
        student5.setAge("61");
        Student student6 = new Student("","6");
        student6.setAge("18");
        studentList.add(student1);
        studentList.add(student2);
        studentList.add(student3);
        studentList.add(student4);
        studentList.add(student5);
        studentList.add(student6);
    }
}
