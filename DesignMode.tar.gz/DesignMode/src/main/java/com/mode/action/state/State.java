package com.mode.action.state;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/9/29 下午5:49
 */

/**
 * 抽象状态类
 * @author zhangmr
 */
public interface State {

    /**
     * 执行状态
     * @param context
     */
    void handle(Context context);
}
