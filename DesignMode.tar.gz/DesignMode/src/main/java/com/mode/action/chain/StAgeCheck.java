package com.mode.action.chain;

import com.mode.action.iterator.Student;
import com.mode.util.StringUtils;

import java.util.List;
import java.util.stream.Collectors;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/10/11 上午9:45
 */

/**
 * 具体处理类
 * @author zhangmr
 */
public class StAgeCheck extends AbstractCheckStudent{
    @Override
    public List<Student> checkStudent(List<Student> studentList) {
        //查找年龄为空或>=60或<=0的集合
        List<Student> stAgeIsNotOk = studentList.stream().filter(student -> {
            String stAge = student.getAge();
            return checkAge(stAge);
        }).collect(Collectors.toList());

        System.out.println("不符合年龄条件的学生："+stAgeIsNotOk.toString());
        //去除name为空的学生
        studentList.removeAll(stAgeIsNotOk);
        System.out.println("符合年龄条件的学生："+studentList.toString());
        return studentList;
    }

    /**
     * 检测不符合条件的年龄
     * @param age 年龄
     * @return 是否符合条件
     */
    private boolean checkAge(String age){
        if (StringUtils.isEmpty(age)){
            return true;
        }else {
            int ageInt = Integer.parseInt(age);
            return ageInt <= 0 || ageInt >= 60;
        }
    }
}
