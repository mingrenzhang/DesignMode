package com.mode.action.mediator;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/10/9 下午3:42
 * 行为模式-中介者模式
 */

public class MediatorMain {
    public static void main(String[] args) {

        ConcretMediator concretMediator = new ConcretMediator();
        Colleague1 colleague1 = new Colleague1(concretMediator);
        Colleague2 colleague2 = new Colleague2(concretMediator);
        concretMediator.setColleague1(colleague1);
        concretMediator.setColleague2(colleague2);
        colleague1.send("hello");
        colleague2.send("world");

    }
}
