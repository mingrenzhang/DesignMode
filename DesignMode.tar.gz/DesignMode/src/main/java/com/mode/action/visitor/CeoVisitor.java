package com.mode.action.visitor;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/9/29 下午3:45
 * 具体访问者
 */

public class CeoVisitor implements Visitor{
    @Override
    public void visit(Engineer engineer) {
        System.out.println("工程师："+engineer.getName()+",KPI：+"+engineer.getKpi());
    }

    @Override
    public void visit(Manager manager) {
        System.out.println("项目经理："+manager.getName()+",KPI："+manager.getKpi()+",项目数："+manager.getProductNum());
    }
}
