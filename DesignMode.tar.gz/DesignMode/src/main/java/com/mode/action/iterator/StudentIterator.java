package com.mode.action.iterator;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/10/9 下午4:54
 */

/**
 * 抽象迭代期类
 * @author zhangmr
 */
public interface StudentIterator {
    /**
     * 是否有下一个元素
     * @return
     */
    boolean hasNext();

    /**
     * 下一个元素
     * @return
     */
    Student next();
}
