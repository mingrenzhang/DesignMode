package com.mode.action.iterator;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/10/9 下午5:06
 */

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * 行为模式-迭代器模式
 * @author zhangmr
 */
public class IteratorMain {
    public static void main(String[] args) {
        StudentAggregate studentAggregate = new StudentAggregateImpl();
        studentAggregate.addStudent(new Student("张三","1"));
        studentAggregate.addStudent(new Student("李四","2"));
        studentAggregate.addStudent(new Student("小明","3"));

        //自定义的迭代器
        StudentIterator iterator = studentAggregate.getIterator();
        while (iterator.hasNext()){
            System.out.println("student:"+iterator.next());
        }

        //JDK中list的迭代器
        List<Student> list = new ArrayList<>();
        list.add(new Student("张三","1"));
        list.add(new Student("李四","2"));
        Iterator iterator1 = list.listIterator();
        //listIterator和iterator区别:iterator可以遍历set和list
        //Iterator iterator2 = list.iterator();
        while (iterator1.hasNext()){
            System.out.println(iterator1.next());
        }
    }
}
