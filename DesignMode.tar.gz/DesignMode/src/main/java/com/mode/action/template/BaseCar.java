package com.mode.action.template;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/9/29 下午4:47
 */

/**
 * 抽象类
 * @author zhangmr
 */
public abstract class BaseCar {

    /**
     * 开始行驶
     */
    public abstract void start();

    /**
     * 停止
     */
    public abstract void stop();

    /**
     * 鸣笛
     */
    public abstract void alarm();

    private void enter(){
        System.out.println("enter car");
    }

    public void run(){
        enter();
        start();
        alarm();
        stop();
    }
}
