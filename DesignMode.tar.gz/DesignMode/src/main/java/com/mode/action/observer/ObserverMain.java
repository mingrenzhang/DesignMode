package com.mode.action.observer;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/9/30 上午10:17
 * 行为模式-观察者模式
 */

public class ObserverMain {

    public static void main(String[] args) {
        WeChat user1 = new WeChat("张三");
        WeChat user2 = new WeChat("李四");

        WeChatSubject weChatSubject = new WeChatSubject();
        weChatSubject.addObserver(user1);
        weChatSubject.addObserver(user2);

        weChatSubject.notifyObserver("你好！");

    }
}
