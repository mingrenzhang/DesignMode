package com.mode.action.iterator;

import java.util.ArrayList;
import java.util.List;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/10/9 下午5:03
 */

/**
 * 具体容器类
 * @author zhangmr
 */
public class StudentAggregateImpl implements StudentAggregate{

    List<Student> list = new ArrayList<>();

    @Override
    public void addStudent(Student student) {
        list.add(student);
    }

    @Override
    public void removeStudent(Student student) {
        list.remove(student);
    }

    @Override
    public StudentIterator getIterator() {
        return new StudentIteratorImpl(list);
    }
}
