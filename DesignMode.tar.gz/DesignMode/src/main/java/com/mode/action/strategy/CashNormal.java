package com.mode.action.strategy;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/9/29 下午5:11
 * 具体策略类
 */

public class CashNormal implements CashStrategy{

    @Override
    public double acceptCash(double money) {
        return money;
    }
}
