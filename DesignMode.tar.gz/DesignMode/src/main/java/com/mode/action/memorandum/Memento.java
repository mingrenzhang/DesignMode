package com.mode.action.memorandum;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/10/9 下午2:53
 * 备忘录
 */

public class Memento {

    private String state;

    public Memento(String state){
        this.state = state;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }
}
