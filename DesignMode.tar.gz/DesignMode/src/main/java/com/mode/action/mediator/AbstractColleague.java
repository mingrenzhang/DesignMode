package com.mode.action.mediator;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/10/9 下午3:22
 * 抽象同事类
 */

public abstract class AbstractColleague {

    private AbstractMediator mediator;

    public AbstractColleague(AbstractMediator mediator){
        this.mediator = mediator;
    }

    public AbstractMediator getMediator() {
        return mediator;
    }

    /**
     * 发送消息
     * @param message
     */
    public abstract void send(String message);

    /**
     * 接收通知消息
     * @param message
     */
    public abstract void notifyMessage(String message);
}
