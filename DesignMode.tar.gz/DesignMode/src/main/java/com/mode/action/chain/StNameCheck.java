package com.mode.action.chain;

import com.mode.action.iterator.Student;
import com.mode.util.StringUtils;

import java.util.List;
import java.util.stream.Collectors;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/10/11 上午9:35
 */

/**
 * 具体处理类
 * @author zhangmr
 */
public class StNameCheck extends AbstractCheckStudent{
    @Override
    public List<Student> checkStudent(List<Student> studentList) {
        //查找姓名为空的学生集合
        List<Student> stNameIsNotOk = studentList.stream().filter(student -> {
            String stName = student.getName();
            return StringUtils.isEmpty(stName);
        }).collect(Collectors.toList());

        System.out.println("不符合姓名条件的学生："+stNameIsNotOk.toString());
        //去除name为空的学生
        studentList.removeAll(stNameIsNotOk);
        System.out.println("符合姓名条件的学生："+studentList.toString());
        return studentList;
    }


}
