package com.mode.action.template;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/9/29 下午4:52
 * 具体子类
 */
public class AudiCar extends BaseCar{
    @Override
    public void start() {
        System.out.println("Audi start");
    }

    @Override
    public void stop() {
        System.out.println("Audi stop");
    }

    @Override
    public void alarm() {
        System.out.println("Audi alarm");
    }
}
