package com.mode.action.iterator;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/10/9 下午5:02
 */

/**
 * 抽象容器类
 * @author zhangmr
 */
public interface StudentAggregate {

    /**
     * 添加学生
     * @param student
     */
    void addStudent(Student student);

    /**
     * 移除学生
     * @param student
     */
    void removeStudent(Student student);

    /**
     * 获取迭代器
     * @return
     */
    StudentIterator getIterator();
}
