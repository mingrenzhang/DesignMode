package com.mode.action.state;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/9/29 下午5:48
 */

/**
 * 环境类
 * @author zhangmr
 */
public class Context {

    private State state;

    public Context(){
        this.state = new ConcreteStateA();
    }

    public State getState() {
        return state;
    }

    public void setState(State state) {
        this.state = state;
    }

    public void handle(){
        state.handle(this);
    }
}
