package com.mode.action.observer;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/9/30 上午10:07
 */

/**
 * 目标类
 * @author zhangmr
 */
public interface Subject {

    /**
     * 增加观察者
     * @param observer
     */
    void addObserver(Observer observer);

    /**
     * 删除观察者
     * @param observer
     */
    void deleteObserver(Observer observer);

    /**
     * 通知观察者
     * @param message
     */
    void notifyObserver(String message);
}
