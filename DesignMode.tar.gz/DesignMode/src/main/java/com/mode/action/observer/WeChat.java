package com.mode.action.observer;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/9/30 上午10:05
 */

/**
 * 具体观察者
 * @author zhangmr
 */
public class WeChat implements Observer{

    private String name;

    public WeChat(String name){
        this.name = name;
    }

    @Override
    public void update(String message) {
        System.out.println("name:"+name+","+"WeChat update message:"+message);
    }
}
