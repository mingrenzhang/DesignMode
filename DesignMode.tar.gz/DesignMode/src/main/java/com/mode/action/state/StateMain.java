package com.mode.action.state;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/9/29 下午5:55
 * 行为模式-状态模式
 */

public class StateMain {

    public static void main(String[] args) {
        Context context = new Context();
        context.handle();
        context.handle();
        context.handle();
        context.handle();
    }


}
