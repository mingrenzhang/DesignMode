package com.mode.action.visitor;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/9/29 下午3:56
 * 行为模式-访问者模式
 */

public class VisitorMain {

    public static void main(String[] args) {

        Engineer engineer1 = new Engineer("张三");
        Engineer engineer2 = new Engineer("李四");

        Manager manager1 = new Manager("张总");
        Manager manager2 = new Manager("李总");

        EmployeeStructure employeeStructure = new EmployeeStructure();
        employeeStructure.addEmployee(engineer1)
                .addEmployee(engineer2)
                .addEmployee(manager1)
                .addEmployee(manager2);
        employeeStructure.report(new CeoVisitor());
        employeeStructure.report(new CtoVisitor());
    }
}
