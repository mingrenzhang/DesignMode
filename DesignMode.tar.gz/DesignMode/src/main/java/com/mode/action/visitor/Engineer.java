package com.mode.action.visitor;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/9/29 下午3:32
 */

import java.util.Random;

/**
 * 具体元素-工程师
 * @author zhangmr
 */
public class Engineer implements Employee{

    private String name;
    private int kpi;

    public Engineer(String name){
        this.name = name;
        this.kpi = new Random().nextInt(10);
    }

    public String getName() {
        return name;
    }

    public int getKpi() {
        return kpi;
    }

    @Override
    public void accept(Visitor visitor) {
        visitor.visit(this);
    }

    public int getCodeLine(){
        return this.kpi * 100000;
    }
}
