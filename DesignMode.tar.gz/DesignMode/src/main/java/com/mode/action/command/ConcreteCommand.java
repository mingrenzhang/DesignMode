package com.mode.action.command;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/10/9 下午5:34
 */

/**
 * 具体命令类
 * @author zhangmr
 */
public class ConcreteCommand implements ICommand {

    private Receiver receiver = new Receiver();

    @Override
    public void execute() {
        receiver.action();
    }
}
