package com.mode.action.command;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/10/9 下午5:33
 */

/**
 * 抽象命令类
 * @author zhangmr
 */
public interface ICommand {

    /**
     * 执行命令
     */
    void execute();
}
