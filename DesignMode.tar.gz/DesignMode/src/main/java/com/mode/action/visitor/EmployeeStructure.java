package com.mode.action.visitor;

import java.util.ArrayList;
import java.util.List;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/9/29 下午3:52
 * 结构对象
 */

public class EmployeeStructure {

    List<Employee> list = new ArrayList<>();

    public EmployeeStructure addEmployee(Employee employee){
        list.add(employee);
        return this;
    }

    public void report(Visitor visitor){
        //遍历执行
        list.forEach(employee ->
                employee.accept(visitor));
    }
}
