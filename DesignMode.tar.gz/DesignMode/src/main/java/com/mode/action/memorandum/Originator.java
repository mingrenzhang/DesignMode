package com.mode.action.memorandum;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/10/9 下午2:54
 * 发起者
 */

public class Originator {

    private String state;

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    /**
     * 创建备忘录
     */
    public Memento createMemento(){
        return new Memento(state);
    }

    /**
     * 从备忘录恢复
     */
    public void restoreMemento(Memento memento){
        this.setState(memento.getState());
    }
}
