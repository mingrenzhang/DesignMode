package com.mode.action.memorandum;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/10/9 下午3:01
 */

/**
 * 行为模式-备忘录模式
 * @author zhangmr
 */
public class MemorandumMain {

    public static void main(String[] args) {
        Originator originator = new Originator();
        originator.setState("state 1");
        System.out.println(originator.getState());

        Caretaker caretaker = new Caretaker();
        caretaker.storeMemento(originator.createMemento());
        originator.setState("state 2");
        System.out.println(originator.getState());

//        caretaker.storeMemento(originator.createMemento());
//        originator.setState("state 3");
//        System.out.println(originator.getState());

        originator.restoreMemento(caretaker.getMemento());
        System.out.println(originator.getState());
    }
}
