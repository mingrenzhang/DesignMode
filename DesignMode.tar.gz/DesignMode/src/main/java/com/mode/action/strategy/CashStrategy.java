package com.mode.action.strategy;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/9/29 下午5:06
 * 抽象策略类
 */

public interface CashStrategy {

    /**
     * 收现金
     * @param money
     * @return
     */
    double acceptCash(double money);
}
