package com.mode.action.command;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/10/9 下午5:34
 */

/**
 * 接收者
 * @author zhangmr
 */
public class Receiver {

    public void action(){
        System.out.println("接收者具体执行");
    }
}
