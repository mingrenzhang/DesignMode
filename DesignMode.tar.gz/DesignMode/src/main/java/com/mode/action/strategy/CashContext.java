package com.mode.action.strategy;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/9/29 下午5:08
 */

/**
 * 环境类
 * @author zhangmr
 */
public class CashContext {

    private CashStrategy cashStrategy;

    public CashContext(CashStrategy cashStrategy){
        this.cashStrategy = cashStrategy;
    }

    public double getResult(double money){
        return cashStrategy.acceptCash(money);
    }
}
