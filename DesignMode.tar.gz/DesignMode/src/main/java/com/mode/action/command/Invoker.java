package com.mode.action.command;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/10/9 下午5:35
 */

/**
 * 调用者
 * @author zhangmr
 */
public class Invoker {

    private ICommand iCommand;

    public Invoker(ICommand iCommand){
        this.iCommand = iCommand;
    }

    public void action(){
        iCommand.execute();
    }
}
