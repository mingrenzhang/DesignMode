package com.mode.action.visitor;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/9/29 下午3:30
 * 抽象访问者
 */

public interface Visitor {

    /**
     * 访问工程师
     * @param engineer
     */
    void visit(Engineer engineer);

    /**
     * 访问管理者
     * @param manager
     */
    void visit(Manager manager);
}
