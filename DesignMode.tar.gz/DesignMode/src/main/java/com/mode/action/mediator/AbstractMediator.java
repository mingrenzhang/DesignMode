package com.mode.action.mediator;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/10/9 下午3:27
 * 抽象中介者
 */

public abstract class AbstractMediator {
    /**
     * 发送消息
     * @param message
     * @param colleague
     */
    public abstract void send(String message,AbstractColleague colleague);
}
