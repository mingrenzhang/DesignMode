package com.mode.action.observer;

import java.util.ArrayList;
import java.util.List;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/9/30 上午10:12
 */
public class WeChatSubject implements Subject{

    List<Observer> list = new ArrayList<>();
    @Override
    public void addObserver(Observer observer) {
        if (!list.contains(observer)){
            list.add(observer);
        }
    }

    @Override
    public void deleteObserver(Observer observer) {
        list.remove(observer);

    }

    @Override
    public void notifyObserver(String message) {
        for (Observer observer1 : list){
            observer1.update(message);
        }
    }
}
