package com.mode.action.mediator;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/10/9 下午3:33
 * 具体同事2
 */

public class Colleague2 extends AbstractColleague{

    public Colleague2(AbstractMediator mediator) {
        super(mediator);
    }

    @Override
    public void send(String message) {
        getMediator().send(message,this);
    }

    @Override
    public void notifyMessage(String message) {
        System.out.println("colleague2 receive message:"+message);
    }
}
