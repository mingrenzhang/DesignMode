package com.mode.action.chain;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/10/9 下午5:55
 */

import com.mode.action.iterator.Student;

import java.util.List;

/**
 * 抽象处理类
 * @author zhangmr
 */
public abstract class AbstractCheckStudent {

    /**
     *包含有自身的一个属性，其作业主要是下一个对数据的处理者
     */
    private AbstractCheckStudent absCheckStudent;

    /**
     * 设定下一个处理者
     */
    public void setAbsCheckStudent(AbstractCheckStudent absCheckStudent) {
        this.absCheckStudent = absCheckStudent;
    }

    public void handleCheck(List<Student> studentList){
        if (studentList != null && !studentList.isEmpty()){
            //执行当前处理者的业务处理方法
            List<Student> checkIsOk = checkStudent(studentList);
            //判断下一个处理者是不是null，且判断数据是否为空
            if (absCheckStudent != null && checkIsOk != null && !checkIsOk.isEmpty()){
                //调用下一个处理者的业务处理方法
                absCheckStudent.handleCheck(checkIsOk);
            }
        }
    }

    /**
     * 过滤符合条件的学生
     * @param studentList 学生列表
     * @return 符合条件的学生列表
     */
    public abstract List<Student> checkStudent(List<Student> studentList);
}
