package com.mode.action.command;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/10/9 下午5:40
 * 行为模式-命令模式
 */

public class CommandMain {
    public static void main(String[] args) {
        ICommand iCommand = new ConcreteCommand();
        Invoker invoker = new Invoker(iCommand);
        invoker.action();
    }
}
