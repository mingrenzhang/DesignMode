package com.mode.action.observer;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/9/30 上午10:05
 */

/**
 * 抽象观察者
 * @author zhangmr
 */
public interface Observer {

    /**
     * 更新
     * @param message
     */
    void update(String message);
}
