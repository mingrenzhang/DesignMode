package com.mode.action.memorandum;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/10/9 下午2:59
 * 负责人
 */

public class Caretaker {

    private Memento memento;

    public Memento getMemento() {
        return memento;
    }

    /**
     * 存储备忘录
     */
    public void storeMemento(Memento memento){
        this.memento = memento;
    }
}
