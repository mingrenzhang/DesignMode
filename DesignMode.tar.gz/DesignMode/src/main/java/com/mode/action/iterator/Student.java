package com.mode.action.iterator;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/10/9 下午4:55
 */
public class Student {

    private String name;
    private String number;
    private String age;

    public Student(String name,String number){
        this.name = name;
        this.number = number;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    @Override
    public String toString() {
        return "Student{" +
                "name='" + name + '\'' +
                ", number='" + number + '\'' +
                ", age='" + age + '\'' +
                '}';
    }
}
