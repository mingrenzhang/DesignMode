package com.mode.action.mediator;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/10/9 下午3:28
 * 具体同事1
 */

public class Colleague1 extends AbstractColleague{

    public Colleague1(AbstractMediator mediator) {
        super(mediator);
    }

    @Override
    public void send(String message) {
        getMediator().send(message,this);
    }

    @Override
    public void notifyMessage(String message) {
        System.out.println("colleague1 receive message:"+message);
    }
}
