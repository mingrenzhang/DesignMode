package com.mode.action.strategy;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/9/29 下午5:11
 */

/**
 * 具体策略类
 * @author zhangmr
 */
public class CashRebate implements CashStrategy{

    private double rebate = 0;

    public CashRebate(double rebate){
        this.rebate = rebate;
    }

    @Override
    public double acceptCash(double money) {
        return money * rebate;
    }
}
