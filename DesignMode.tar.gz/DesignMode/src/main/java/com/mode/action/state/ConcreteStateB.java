package com.mode.action.state;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/9/29 下午5:53
 */

/**
 * 具体状态类
 * @author zhangmr
 */
public class ConcreteStateB implements State{
    @Override
    public void handle(Context context) {
        System.out.println("状态：B");
        context.setState(new ConcreteStateA());
    }
}
