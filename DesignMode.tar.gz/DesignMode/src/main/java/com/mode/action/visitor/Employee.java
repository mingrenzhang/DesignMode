package com.mode.action.visitor;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/9/29 下午3:29
 * 抽象元素-被访问者
 */

public interface Employee {

    /**
     * 接收被访问者
     * @param visitor
     */
    void accept(Visitor visitor);
}
