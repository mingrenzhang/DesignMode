package com.mode.action.template;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/9/29 下午4:53
 */
public class TemplateMain {

    public static void main(String[] args) {
        BaseCar car1 = new BmwCar();
        car1.run();

        BaseCar car2 = new AudiCar();
        car2.run();
    }
}
