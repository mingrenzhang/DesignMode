package com.mode.action.template;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/9/29 下午4:49
 * 具体子类
 */

public class BmwCar extends BaseCar{
    @Override
    public void start() {
        System.out.println("Bmw start");
    }

    @Override
    public void stop() {
        System.out.println("Bmw stop");
    }

    @Override
    public void alarm() {
        System.out.println("Bmw alarm");
    }
}
