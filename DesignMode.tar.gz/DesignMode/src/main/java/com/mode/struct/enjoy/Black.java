package com.mode.struct.enjoy;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/9/28 上午10:22
 * 具体享元类
 */

public class Black extends AbstractAlphaGo{
    @Override
    public String getColor() {
        return "黑色";
    }
}
