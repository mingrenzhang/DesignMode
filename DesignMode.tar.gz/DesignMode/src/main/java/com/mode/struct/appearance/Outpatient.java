package com.mode.struct.appearance;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/9/28 上午9:53
 */
public class Outpatient {
    public Outpatient(){
        System.out.println("就诊处理...");
    }
}
