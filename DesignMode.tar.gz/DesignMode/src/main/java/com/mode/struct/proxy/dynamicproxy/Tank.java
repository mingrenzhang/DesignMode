package com.mode.struct.proxy.dynamicproxy;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/9/29 上午11:24
 */

import com.mode.struct.proxy.dynamicproxy.jdk.Moveable;

/**
 * 真实角色
 * @author zhangmr
 */
public class Tank implements Moveable {
    @Override
    public void move() {
        System.out.println("Tank is moving");
    }
}
