package com.mode.struct.bridge;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/9/26 上午11:29
 * 结构型模式-桥接模式
 */

public class BridgeMain {
    public static void main(String[] args) {
        AbstractRoad road1 = new UnpaveRoad(new Car());
        road1.driveOnRoad();
        AbstractRoad road2 = new CementRoad(new Bus());
        road2.driveOnRoad();
    }
}
