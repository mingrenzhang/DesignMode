package com.mode.struct.adapter.interfaceadapter;

import com.mode.struct.adapter.AbstractAc220;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/9/22 下午3:47
 */
public class PowerAdapter2 implements Dc{

    private AbstractAc220 ac220;

    public PowerAdapter2(AbstractAc220 ac220){
        this.ac220 = ac220;
    }

    @Override
    public int output5V() {
        int adapterInput = ac220.outAc220();
        int adapterOutput = adapterInput / 44;
        System.out.println("输入电压："+adapterInput+",输出电压："+adapterOutput);
        return adapterOutput;
    }

    @Override
    public int output10V() {
        return 0;
    }

    @Override
    public int output15V() {
        return 0;
    }

    @Override
    public int output20V() {
        return 0;
    }
}
