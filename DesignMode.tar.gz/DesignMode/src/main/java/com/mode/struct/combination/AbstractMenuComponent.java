package com.mode.struct.combination;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/9/26 下午2:58
 * 抽象构件
 */

public abstract class AbstractMenuComponent {

    public String getName(){
        throw new UnsupportedOperationException("暂不支持该操作");
    }

    public String getDescription(){
        throw new UnsupportedOperationException("暂不支持该操作");
    }

    public double getPrice(){
        throw new UnsupportedOperationException("暂不支持该操作");
    }

    public void print(){
        throw new UnsupportedOperationException("暂不支持该操作");
    }

    public boolean isVegetarian(){
        throw new UnsupportedOperationException("暂不支持该操作");
    }

    public void add(AbstractMenuComponent menuComponent){
        throw new UnsupportedOperationException("暂不支持该操作");
    }

    public void remove(AbstractMenuComponent menuComponent){
        throw new UnsupportedOperationException("暂不支持该操作");
    }

    public AbstractMenuComponent getChild(int i){
        throw new UnsupportedOperationException("暂不支持该操作");
    }

}
