package com.mode.struct.enjoy;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/9/28 上午10:20
 * 抽象享元类
 */

public abstract class AbstractAlphaGo {

    /**
     * 获取棋子颜色抽象类
     * @return
     */
    public abstract String getColor();

    public void display(Coordinates coordinates){
        System.out.println("棋子颜色："+getColor()+",棋子位置：("+coordinates.getX()+","+coordinates.getY()+")");
    }
}
