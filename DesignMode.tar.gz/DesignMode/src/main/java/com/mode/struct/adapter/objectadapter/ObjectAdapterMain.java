package com.mode.struct.adapter.objectadapter;

import com.mode.struct.adapter.AbstractAc220;
import com.mode.struct.adapter.Dc5V;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/9/22 下午3:33
 */

/**
 * 结构型模式-适配者模式-对象适配器
 * 通过适配器实现target，适配器内部持有Adaptee实例来转换
 * @author zhangmr
 */
public class ObjectAdapterMain {

    public static void main(String[] args) {
        Dc5V dc5V = new PowerAdapter1(new AbstractAc220());
        dc5V.output5v();
    }
}
