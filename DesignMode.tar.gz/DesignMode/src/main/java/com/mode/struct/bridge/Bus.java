package com.mode.struct.bridge;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/9/26 上午11:19
 */

/**
 * 具体实现类--具体实现化角色
 * @author zhangmr
 */
public class Bus implements Vehicle{

    @Override
    public void driver() {
        System.out.println("Bus is driving");
    }
}
