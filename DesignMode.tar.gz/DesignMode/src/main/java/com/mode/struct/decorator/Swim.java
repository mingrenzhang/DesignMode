package com.mode.struct.decorator;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/9/28 上午9:36
 * 具体装饰类
 */

public class Swim extends Master{


    public Swim(AbstractPerson person) {
        super(person);
    }

    @Override
    public void sport() {
        super.sport();
        teachSwimming();
    }

    public void teachSwimming(){
        System.out.println("学会了游泳");
    }
}
