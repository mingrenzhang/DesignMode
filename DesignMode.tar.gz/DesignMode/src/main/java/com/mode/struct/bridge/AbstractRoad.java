package com.mode.struct.bridge;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/9/26 上午11:21
 * 抽象类
 */
public abstract class AbstractRoad {
    protected Vehicle vehicle;

    public AbstractRoad(Vehicle vehicle){
        this.vehicle = vehicle;
    }

    /**
     * 抽象方法
     */
    public abstract void driveOnRoad();
}
