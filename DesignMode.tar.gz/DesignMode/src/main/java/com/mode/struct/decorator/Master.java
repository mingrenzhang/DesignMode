package com.mode.struct.decorator;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/9/28 上午9:34
 * 抽象装饰类
 */

public class Master extends AbstractPerson{

    protected AbstractPerson person;

    public Master(AbstractPerson person){
        this.person = person;
    }

    @Override
    public void sport() {
        person.sport();
    }
}
