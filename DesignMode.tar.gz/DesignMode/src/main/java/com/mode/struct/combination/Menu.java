package com.mode.struct.combination;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/9/26 下午3:21
 */

import java.util.ArrayList;
import java.util.List;

/**
 * 容器构件
 * @author zhangmr
 */
public class Menu extends AbstractMenuComponent{

    private String name;
    private String desc;
    List<AbstractMenuComponent> menuComponentList = new ArrayList<>();

    public Menu(String name,String desc){
        this.name = name;
        this.desc = desc;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public String getDescription() {
        return desc;
    }

    @Override
    public void print() {
        System.out.println("menu{"+name+","+desc+"}");

        for (AbstractMenuComponent menuComponent : menuComponentList){
            menuComponent.print();
        }
    }

    @Override
    public void add(AbstractMenuComponent menuComponent) {
        menuComponentList.add(menuComponent);
    }

    @Override
    public void remove(AbstractMenuComponent menuComponent) {
        menuComponentList.remove(menuComponent);
    }

    @Override
    public AbstractMenuComponent getChild(int i) {
        if (menuComponentList.size() <= i){
            return null;
        }
        return menuComponentList.get(i);
    }
}
