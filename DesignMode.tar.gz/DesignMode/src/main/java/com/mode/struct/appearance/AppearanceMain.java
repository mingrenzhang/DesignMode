package com.mode.struct.appearance;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/9/28 上午10:01
 * 结构型模式-外观模式
 */

public class AppearanceMain {

    public static void main(String[] args) {
        Hospital hospital = new Hospital();
        hospital.selector();
    }
}
