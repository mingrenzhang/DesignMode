package com.mode.struct.adapter.interfaceadapter;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/9/22 下午3:46
 */
public interface Dc {
    /**
     * 输出5V
     * @return
     */
    int output5V();
    /**
     * 输出10V
     * @return
     */
    int output10V();
    /**
     * 输出15V
     * @return
     */
    int output15V();
    /**
     * 输出20V
     * @return
     */
    int output20V();
}
