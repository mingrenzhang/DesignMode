package com.mode.struct.combination;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/9/26 下午4:31
 * 结构型模式-组合模式
 */

public class CombinationMain {
    public static void main(String[] args) {
        Waitress waitress = new Waitress();
        waitress.printMenu();
    }
}
