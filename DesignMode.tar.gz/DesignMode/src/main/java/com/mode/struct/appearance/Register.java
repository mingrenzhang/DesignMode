package com.mode.struct.appearance;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/9/28 上午9:51
 */
public class Register {
    public Register(){
        System.out.println("挂号处理...");
    }
}
