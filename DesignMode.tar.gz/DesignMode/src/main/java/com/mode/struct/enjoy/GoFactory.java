package com.mode.struct.enjoy;

import java.util.HashMap;
import java.util.Map;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/9/28 上午10:56
 */
public class GoFactory {

    private Map map = new HashMap();
    private static GoFactory goFactory;

    private GoFactory(){
        map.put("b",new Black());
    }
    public static GoFactory getInstance(){
        if (goFactory == null){
            synchronized (GoFactory.class){
                if (goFactory == null){
                    goFactory = new GoFactory();
                }
            }
        }
        return goFactory;
    }

    public AbstractAlphaGo getGo(String color){
        return (AbstractAlphaGo) map.get(color);
    }
}
