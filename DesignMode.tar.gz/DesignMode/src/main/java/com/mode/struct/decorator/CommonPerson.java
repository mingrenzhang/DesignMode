package com.mode.struct.decorator;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/9/28 上午9:30
 * 具体构件
 */

public class CommonPerson extends AbstractPerson{
    @Override
    public void sport() {
        System.out.println("普通人会走路");
    }
}
