package com.mode.struct.adapter.objectadapter;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/9/22 下午3:30
 */

import com.mode.struct.adapter.AbstractAc220;
import com.mode.struct.adapter.Dc5V;

/**
 * 适配器adapter
 * @author zhangmr
 */
public class PowerAdapter1 implements Dc5V {

    private AbstractAc220 ac220;

    public PowerAdapter1(AbstractAc220 ac220){
        this.ac220 = ac220;
    }

    @Override
    public int output5v() {
        int adapterInput = ac220.outAc220();
        int adapterOutput = adapterInput / 44;
        System.out.println("输入电压："+adapterInput+",输出电压："+adapterOutput);
        return adapterOutput;
    }
}
