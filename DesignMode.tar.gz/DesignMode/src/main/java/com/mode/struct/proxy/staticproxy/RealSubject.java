package com.mode.struct.proxy.staticproxy;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/9/29 上午9:53
 * 真实主题角色
 */

public class RealSubject implements SubProxy{
    @Override
    public void request() {
        System.out.println("真实主题角色");
    }
}
