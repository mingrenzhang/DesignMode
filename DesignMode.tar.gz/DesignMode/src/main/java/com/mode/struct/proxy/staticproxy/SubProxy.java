package com.mode.struct.proxy.staticproxy;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/9/29 上午9:52
 */

/**
 * 抽象主题角色
 * @author zhangmr
 */
public interface SubProxy {
    /**
     * 请求
     */
    void request();
}
