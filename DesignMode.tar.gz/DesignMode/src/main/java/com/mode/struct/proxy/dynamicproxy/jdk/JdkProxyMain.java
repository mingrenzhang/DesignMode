package com.mode.struct.proxy.dynamicproxy.jdk;

import com.mode.struct.proxy.dynamicproxy.Tank;

import java.lang.reflect.Proxy;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/9/29 下午1:31
 */

/**
 * 结构型模式-代理模式-jdk动态代理
 * @author zhangmr
 */
public class JdkProxyMain {

    public static void main(String[] args) {
        Moveable moveable = new Tank();
        //创建代理对象
        Moveable o = (Moveable) Proxy.newProxyInstance(Tank.class.getClassLoader(),new Class[]{Moveable.class},new LogProxy(moveable));
        o.move();
    }
}
