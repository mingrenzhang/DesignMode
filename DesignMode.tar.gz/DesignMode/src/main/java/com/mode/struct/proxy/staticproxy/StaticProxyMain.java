package com.mode.struct.proxy.staticproxy;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/9/29 上午9:58
 */

/**
 * 结构型模式-代理模式-静态代理
 * @author zhangmr
 */
public class StaticProxyMain {
    public static void main(String[] args) {
        SubProxy proxy = new Proxy();
        proxy.request();

        Proxy2 proxy2 = new Proxy2();
        proxy2.request();
    }
}
