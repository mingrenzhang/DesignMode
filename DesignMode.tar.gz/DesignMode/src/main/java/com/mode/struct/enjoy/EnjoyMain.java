package com.mode.struct.enjoy;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/9/28 上午11:40
 * 结构型模式-享元模式
 */
public class EnjoyMain {
    public static void main(String[] args) {
        GoFactory factory = GoFactory.getInstance();

        AbstractAlphaGo black01 = factory.getGo("b");
        AbstractAlphaGo black02 = factory.getGo("b");

        System.out.println("黑棋是否相同："+(black01 == black02));

        black01.display(new Coordinates(1,2));
        black02.display(new Coordinates(2,3));
    }
}
