package com.mode.struct.bridge;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/9/26 上午11:17
 */

/**
 * 实现类接口--实视化角色
 * @author zhangmr
 */
public interface Vehicle {
    /**
     * 驾驶
     */
    void driver();
}
