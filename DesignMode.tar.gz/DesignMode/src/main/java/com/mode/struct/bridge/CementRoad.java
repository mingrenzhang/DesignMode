package com.mode.struct.bridge;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/9/26 上午11:28
 * 扩充抽象类--扩展抽象化角色
 */

public class CementRoad extends AbstractRoad{
    public CementRoad(Vehicle vehicle) {
        super(vehicle);
    }

    @Override
    public void driveOnRoad() {
        super.vehicle.driver();
        System.out.println("行驶在水泥路");
    }
}
