package com.mode.struct.decorator;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/9/28 上午9:29
 * 抽象构件
 */

public abstract class AbstractPerson {

    /**
     * 抽象运动类
     */
    public abstract void sport();
}
