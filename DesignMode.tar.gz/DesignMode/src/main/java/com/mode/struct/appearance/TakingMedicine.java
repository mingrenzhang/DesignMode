package com.mode.struct.appearance;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/9/28 上午9:55
 */
public class TakingMedicine {
    public TakingMedicine(){
        System.out.println("取药处理...");
    }
}
