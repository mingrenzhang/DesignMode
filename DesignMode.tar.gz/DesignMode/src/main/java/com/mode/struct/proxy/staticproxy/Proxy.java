package com.mode.struct.proxy.staticproxy;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/9/29 上午9:54
 */

/**
 * 代理角色，在执行真实角色前后增加额外操作
 * 组合方式实现，代理角色及真实角色实现同一接口，jdk动态代理以该种方式实现
 * @author zhangmr
 */
public class Proxy implements SubProxy {

    private RealSubject realSubject = null;
    @Override
    public void request() {
        preRequest();

        if (realSubject == null){
            realSubject = new RealSubject();
        }
        realSubject.request();


        postRequest();
    }

    private void preRequest(){
        System.out.println("真实角色执行前操作");
    }

    private void postRequest(){
        System.out.println("真实角色执行后操作");
    }
}
