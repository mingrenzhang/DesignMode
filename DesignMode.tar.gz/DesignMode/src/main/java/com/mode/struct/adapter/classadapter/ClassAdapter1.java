package com.mode.struct.adapter.classadapter;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/9/22 下午3:13
 */

import com.mode.struct.adapter.Dc5V;

/**
 * 结构型模式-适配者模式-类适配器
 * 通过继承Adaptee实现target来转换
 * @author zhangmr
 */
public class ClassAdapter1 {

    public static void main(String[] args) {
        //创建适配器实例
        Dc5V dc5V = new PowerAdapter();
        dc5V.output5v();
    }
}
