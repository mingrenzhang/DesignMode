package com.mode.struct.proxy.dynamicproxy.jdk;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/9/29 上午11:23
 */
public interface Moveable {
    /**
     * 执行方法
     */
    void move();
}
