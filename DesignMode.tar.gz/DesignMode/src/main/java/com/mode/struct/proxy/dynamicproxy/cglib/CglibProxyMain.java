package com.mode.struct.proxy.dynamicproxy.cglib;

import com.mode.struct.proxy.dynamicproxy.Tank;
import net.sf.cglib.proxy.Enhancer;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/9/29 下午1:56
 */

/**
 * 结构型模式-代理模式-cglib动态代理
 * @author zhangmr
 */
public class CglibProxyMain {
    public static void main(String[] args) {
        //增加者
        Enhancer enhancer = new Enhancer();
        //指定父类
        enhancer.setSuperclass(Tank.class);
        //当被代理对象的方法调用的时候会调用该对象的intercept
        enhancer.setCallback(new TimeMethodInterceptor());
        //动态代理的生成
        Tank tank = (Tank) enhancer.create();
        //动态代理生成之后执行
        tank.move();
    }
}
