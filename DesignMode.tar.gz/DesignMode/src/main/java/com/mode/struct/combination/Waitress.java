package com.mode.struct.combination;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/9/26 下午3:59
 */
public class Waitress {

    private AbstractMenuComponent menuComponent;

    public void printMenu(){
        initMenu();
        menuComponent.print();
    }

    public void initMenu(){
        menuComponent = new Menu("菜单","menu");

        AbstractMenuComponent menuComponent1 = new Menu("早餐","total");
        menuComponent1.add(new MenuItem("包子","bun",true,1.5));
        menuComponent1.add(new MenuItem("油条","fritter",true,1.2));
        menuComponent.add(menuComponent1);

        AbstractMenuComponent menuComponent2 = new Menu("午餐","total");
        AbstractMenuComponent menuComponent3 = new Menu("午餐","南方菜");
        menuComponent3.add(new MenuItem("蒸排骨","meat",true,35));
        menuComponent3.add(new MenuItem("炒米粉","rice",true,25));
        menuComponent2.add(menuComponent3);
        menuComponent.add(menuComponent2);

        AbstractMenuComponent menuComponent4 = new MenuItem("甜点","冰淇淋",true,10);
        menuComponent.add(menuComponent4);
    }
}
