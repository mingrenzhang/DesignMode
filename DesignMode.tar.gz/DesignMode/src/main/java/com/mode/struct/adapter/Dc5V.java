package com.mode.struct.adapter;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/9/22 下午3:07
 */

/**
 * 目标接口target
 * 符合需求的接口，但是无法访问到
 * @author zhangmr
 */
public interface Dc5V {
    /**
     * 输出5V
     * @return
     */
    int output5v();
}
