package com.mode.struct.bridge;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/9/26 上午11:25
 * 扩充抽象类--扩展抽象化角色
 */

public class UnpaveRoad extends AbstractRoad {

    public UnpaveRoad(Vehicle vehicle) {
        super(vehicle);
    }

    @Override
    public void driveOnRoad() {
        super.vehicle.driver();
        System.out.println("行驶在柏油路");
    }
}
