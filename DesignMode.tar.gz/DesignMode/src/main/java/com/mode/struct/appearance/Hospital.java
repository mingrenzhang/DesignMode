package com.mode.struct.appearance;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/9/28 上午9:56
 */

/**
 * 外观角色，提供统一接口访问多个子系统接口
 * @author zhangmr
 */
public class Hospital {

    private Register register;
    private Outpatient outpatient;
    private Pay pay;
    private TakingMedicine takingMedicine;

    public Hospital(){

    }

    public Hospital(Register register,Outpatient outpatient,Pay pay,TakingMedicine takingMedicine){
        this.register = register;
        this.outpatient = outpatient;
        this.pay = pay;
        this.takingMedicine = takingMedicine;
    }

    public void selector(){
        register = new Register();
        outpatient = new Outpatient();
        pay = new Pay();
        takingMedicine = new TakingMedicine();
    }
}
