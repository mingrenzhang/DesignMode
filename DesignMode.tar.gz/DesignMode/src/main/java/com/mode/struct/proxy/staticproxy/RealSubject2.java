package com.mode.struct.proxy.staticproxy;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/9/29 上午10:12
 */
public class RealSubject2 {
    public void request(){
        System.out.println("真实主题角色2");
    }
}
