package com.mode.struct.decorator;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/9/28 上午9:40
 * 结构型模式-装饰者模式
 */
public class DecoratorMain {
    public static void main(String[] args) {
        CommonPerson commonPerson = new CommonPerson();

        Swim swim = new Swim(commonPerson);
        swim.sport();
    }
}
