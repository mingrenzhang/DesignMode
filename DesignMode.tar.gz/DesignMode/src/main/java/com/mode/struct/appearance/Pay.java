package com.mode.struct.appearance;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/9/28 上午9:54
 */
public class Pay {
    public Pay(){
        System.out.println("缴费处理...");
    }
}
