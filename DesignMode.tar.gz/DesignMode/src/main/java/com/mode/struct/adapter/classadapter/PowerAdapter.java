package com.mode.struct.adapter.classadapter;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/9/22 下午3:09
 */

import com.mode.struct.adapter.AbstractAc220;
import com.mode.struct.adapter.Dc5V;

/**
 * 适配器adapter 通过继承Adaptee实现target来转换
 * @author zhangmr
 */
public class PowerAdapter extends AbstractAc220 implements Dc5V {
    /**
     * 将输入AC220转换为DC5V
     */
    @Override
    public int output5v() {
        int adapterInput = super.outAc220();
        int adapterOutput = adapterInput / 44;
        System.out.println("输入电压："+adapterInput+",输出电压："+adapterOutput);
        return adapterOutput;
    }
}
