package com.mode.struct.adapter;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/9/22 下午3:05
 */

/**
 * 结构型模式-适配者模式
 * 源角色Adaptee
 * 用户可以访问，但是不符合需求
 * @author zhangmr
 */
public class AbstractAc220 {

    public int outAc220(){
        System.out.println("输出电压：220V");
        return 220;
    }
}
