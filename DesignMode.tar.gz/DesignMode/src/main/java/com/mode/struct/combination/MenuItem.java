package com.mode.struct.combination;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/9/26 下午2:58
 * 叶子构件
 */
public class MenuItem extends AbstractMenuComponent{

    private String name;
    private String desc;
    private boolean vegetarian;
    private double price;

    public MenuItem(String name,String desc,boolean vegetarian,double price){
        this.name = name;
        this.desc = desc;
        this.vegetarian = vegetarian;
        this.price = price;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public String getDescription() {
        return desc;
    }

    @Override
    public boolean isVegetarian() {
        return vegetarian;
    }

    @Override
    public double getPrice() {
        return price;
    }

    @Override
    public void print() {
        System.out.println("MenuItem{"+name+","+desc+","+vegetarian+","+price+"}");
    }
}
