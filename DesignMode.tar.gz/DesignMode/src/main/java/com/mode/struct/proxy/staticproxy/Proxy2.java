package com.mode.struct.proxy.staticproxy;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/9/29 上午9:54
 */

/**
 * 代理角色，在执行真实角色前后增加额外操作
 * 继承真实角色,cglib动态代理以该种方式实现
 * @author zhangmr
 */
public class Proxy2 extends RealSubject2 {

    @Override
    public void request() {
        preRequest();
        super.request();
        postRequest();
    }

    private void preRequest(){
        System.out.println("真实角色2执行前操作");
    }

    private void postRequest(){
        System.out.println("真实角色2执行后操作");
    }
}
