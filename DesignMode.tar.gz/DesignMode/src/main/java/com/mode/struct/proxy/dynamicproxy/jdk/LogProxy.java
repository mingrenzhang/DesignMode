package com.mode.struct.proxy.dynamicproxy.jdk;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/9/29 上午11:26
 */

/**
 *代理对象映射，代理对象中增加前后操作
 * @author zhangmr
 */
public class LogProxy implements InvocationHandler {

    private Moveable moveable;

    public LogProxy(Moveable moveable){
        this.moveable = moveable;
    }

    @Override
    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        preOperate();
        //动态映射到真实对象方法
        Object invoke = method.invoke(moveable,args);
        afterOperate();
        return invoke;
    }

    private void preOperate(){
        System.out.println("before operate");
    }

    private void afterOperate(){
        System.out.println("after operate");
    }
}
