package com.mode.struct.adapter.interfaceadapter;

import com.mode.struct.adapter.AbstractAc220;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/9/22 下午3:52
 * 结构型模式-适配者模式-接口适配器
 */

public class InterfaceAdapterMain {

    public static void main(String[] args) {
        Dc dc = new PowerAdapter2(new AbstractAc220());
        dc.output5V();
    }
}
