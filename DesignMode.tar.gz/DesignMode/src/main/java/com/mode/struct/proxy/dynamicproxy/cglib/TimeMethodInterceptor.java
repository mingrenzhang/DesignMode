package com.mode.struct.proxy.dynamicproxy.cglib;

import net.sf.cglib.proxy.MethodInterceptor;
import net.sf.cglib.proxy.MethodProxy;

import java.lang.reflect.Method;

/**
 * @author zhangmr
 * @version 1.0
 * @date 2022/9/29 下午1:47
 */
public class TimeMethodInterceptor implements MethodInterceptor {
    @Override
    public Object intercept(Object o, Method method, Object[] objects, MethodProxy methodProxy) throws Throwable {

        System.out.println("生成的类名："+o.getClass().getName());
        System.out.println("生成的类的父类："+o.getClass().getSuperclass().getName());
        preOperate();
        Object result = methodProxy.invokeSuper(o,objects);
        afterOperate();
        return result;
    }

    private void preOperate(){
        System.out.println("before operate");
    }

    private void afterOperate(){
        System.out.println("after operate");
    }
}
